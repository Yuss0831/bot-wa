const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  getContentType,
  jidDecode,
  downloadContentFromMessage
} = require('@whiskeysockets/baileys');
const pino = require('pino');
const { Boom } = require('@hapi/boom');
const fs = require('fs');
const setting = require('./setting');

let caseHandler = require('./case'); // awal load

// 🔁 Auto Reload case.js saat diubah
fs.watchFile(require.resolve('./case'), () => {
  delete require.cache[require.resolve('./case')];
  caseHandler = require('./case');
  console.log('♻️ case.js diperbarui');
});

async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState('session');

  const conn = makeWASocket({
    logger: pino({ level: 'silent' }),
    printQRInTerminal: false,
    auth: state,
    browser: [setting.namabot, 'Chrome', '1.0.0']
  });

    
  conn.decodeJid = (jid) => {
  if (!jid) return jid;
  if (/:\d+@/gi.test(jid)) {
    const decode = jidDecode(jid) || {};
    return (decode.user && decode.server) ? `${decode.user}@${decode.server}` : jid;
  } else return jid;
};  
    
    
    
  conn.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect } = update;
    if (connection === 'open') {
      console.log(`✅ Bot aktif sebagai: ${conn.user.id}`);
    } else if (connection === 'close') {
      const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
      if (reason !== DisconnectReason.loggedOut) {
        console.log('🔁 Reconnecting...');
        startBot();
      } else {
        console.log('🚫 Bot logout permanen. Hapus session dan login ulang.');
      }
    }
  });

   conn.ev.on('messages.upsert', async ({ messages }) => {
  const msg = messages[0];
  if (!msg.message) return;

  const sender = msg.key.participant || msg.key.remoteJid;
const isOwner = setting.owner.includes(sender?.split('@')[0]);

// ✅ izinkan .public walau dalam mode self
const isPublicCmd = msg.text?.toLowerCase() === '.public';

if (!global.isPublic && !isOwner && !isPublicCmd) return;

  const type = getContentType(msg.message);
  msg.text = msg.message[type]?.text || msg.message[type]?.caption || msg.message.conversation || '';
  msg.chat = msg.key.remoteJid;

   try {
    await conn.readMessages([msg.key]); // AutoRead
    await conn.sendPresenceUpdate('composing', msg.chat); // Ngetik
    await delay(600); // delay 0.6 detik agar realistis
  } catch (e) {
    console.error('[AutoRead/Error Typing]', e);
  }
   
  
  await caseHandler(conn, msg);
});
  
function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

    
    
    
    
    
    
  conn.ev.on('creds.update', saveCreds);
}

global.isPublic = true; // default mode: public



startBot();