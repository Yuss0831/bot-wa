const {
  getContentType,
  downloadContentFromMessage,
  
} = require('@whiskeysockets/baileys');

const fs = require('fs');
const constOwner = "6283176775170";

// 🆄🆂🅴🆁 🅳🅰🆃🅰🅱🅰🆂🅴
const dbPath = './database/user.json';
const backupPath = './database/user-backup.json';
if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, '{}');

let users = {};
try {
  users = JSON.parse(fs.readFileSync(dbPath));
} catch {
  users = {};
}

function saveDB() {
  fs.writeFileSync(dbPath, JSON.stringify(users, null, 2));
  fs.writeFileSync(backupPath, JSON.stringify(users, null, 2));
} 

function getUser(id) {
  if (!users[id]) {
    users[id] = {
      nama: null,
      umur: null,
      
      uang: 20000,
      xp: 0,
      tiket: 0,
      level: 1,
      limit: 10,
      heal: 100,
      stamina: 100,  
      registeredAt: Date.now(),
      lastClaim: 0,
      toxic: 0  
    };
    saveDB();
  }
  return users[id];
}

function updateUser(id, data) {
  users[id] = { ...getUser(id), ...data };
  saveDB();
}
//🅿🆁🅴🅼🅸🆄🅼 🅳🅰🆃🅰🅱🅰🆂🅴

const premPath = './database/premium.json';
let premium = fs.existsSync(premPath) ? JSON.parse(fs.readFileSync(premPath)) : [];

//🅰🅽🆃🅸🅻🅸🅽🅺 🅳🅰🆃🅰🅱🅰🆂🅴

const antilinkPath = './database/antilink.json';
let antilinkData = JSON.parse(fs.readFileSync(antilinkPath));

// Simpan ke file
function saveAntilink() {
  fs.writeFileSync(antilinkPath, JSON.stringify(antilinkData, null, 2));
}


//🅰🅽🆃🅸🅸 🆃🅾🆇🅸🅲🅲🅲🅲

const antiToxicStatus = JSON.parse(fs.readFileSync('./database/antitoxic.json', 'utf8'));

function saveAntiToxic() {
  fs.writeFileSync('./database/antitoxic.json', JSON.stringify(antiToxicStatus, null, 2));
}
//🅰🅽🆃🅸🆂🆃🅸🅺🅴🆁 🅳🅰🆃🅰🅱🅰🆂🅴

const antistikerPath = './database/antistiker.json';
let antiStickerStatus = fs.existsSync(antistikerPath) ? JSON.parse(fs.readFileSync(antistikerPath)) : {};

function saveAntiSticker() {
  fs.writeFileSync(antistikerPath, JSON.stringify(antiStickerStatus, null, 2));
}


//====================================
module.exports = async (conn, m) => {
 // const { text } = m;
   const contentType = getContentType(m.message);
const text = m.message?.conversation || m.message[contentType]?.text || m.message[contentType]?.caption || '';
const selectedButton = contentType === 'buttonsResponseMessage' ? m.message.buttonsResponseMessage.selectedButtonId : null;
const command = (selectedButton || text).toLowerCase();
 const args = text.trim().split(/\s+/);
  m.reply = (text) => conn.sendMessage(m.chat, { text }, { quoted: m });  

const normalisasi = jid => (typeof jid === 'string' ? jid.replace(/:[0-9]+/g, '') : '');
    
 
    
    
    
  // 🔒 Penanganan pengirim aman
  const senderJid = m.sender || m.key.participant || m.key.remoteJid || '';
  const sender = senderJid ? (conn.decodeJid(senderJid)?.split('@')[0] || '') : '';
  m.isGroup = m.chat.endsWith('@g.us');  
    
  const user = getUser(sender);
    
  
    
  //🅿🅴🅽🅶🅴🅲🅴🅺🅰🅽🅽 🅻🅸🅽🅺  
if (m.isGroup && antilinkData[m.chat]) {
  const groupMetadata = await conn.groupMetadata(m.chat);
  const participants = groupMetadata.participants;

  const senderId = conn.decodeJid(m.sender || m.key.participant || '');
  const isAdmin = participants.some(p => p.id === senderId && p.admin);

  const body = text || '';
  const regexLink = /(https?:\/\/[^\s]+)/gi;
  const links = body.match(regexLink);

  if (links) {
    const whitelist = /(tiktok\.com|vt\.tiktok\.com|tiktoklite\.com|youtube\.com|youtu\.be)/i;
    const terlarang = links.filter(link => !whitelist.test(link));

    if (terlarang.length > 0 && !isAdmin && !m.key.fromMe) {
      // Hapus pesan
      await conn.sendMessage(m.chat, { delete: m.key });

      // Kirim peringatan
      await conn.sendMessage(m.chat, {
        text: `⚠️ @${senderId.split('@')[0]} mohon *jangan kirim link* ke grup ini!`,
        mentions: [senderId],
      });
    }
  }
}
  
//🅰🅽🆃🅸🆃🅾🆇🅸🅲🅲 🅿🅴🅽🅶🅴🅲🅴🅺🅰🅽    
  const kataToxic = ['anjing', 'babi', 'kontol', 'memek', 'tolol', 'goblok', 'bego', 'asu', 'stres', 'lol', 'any', 'anj', 'anjng', 'anjg', 'bgg', 'setan', 'mmk', 'knt', 'kntol', 'kntl', 'awsyu', 'asyu', 'memk', 'monyet', 'mnyet', 'monkey']; // Tambah sesuai kebutuhan

// Cek apakah fitur AntiToxic aktif
if (m.isGroup && text && antiToxicStatus[m.chat]) {
  const groupMetadata = await conn.groupMetadata(m.chat);
  const participants = groupMetadata.participants;
  const senderId = conn.decodeJid(m.sender || m.key.participant || '');
  const isAdmin = participants.some(p => p.id === senderId && p.admin);

  const words = text.toLowerCase().split(/\s+/); // Pisahkan jadi kata per kata

  for (const kata of kataToxic) {
    if (words.includes(kata)) {

      if (isAdmin) break; // ⛔ Admin grup tidak dihitung toxic

      const user = getUser(sender);
      user.toxic = (user.toxic || 0) + 1;
      saveDB();

      // 🧹 Hapus pesan toxic
      await conn.sendMessage(m.chat, { delete: m.key });

      if (user.toxic >= 7) {
        const botNumber = conn.user?.id?.split(':')[0] + '@s.whatsapp.net';
        const isBotAdmin = participants.some(p => p.id === botNumber && p.admin);

        if (isBotAdmin) {
          await conn.sendMessage(m.chat, {
            text: `🚫 @${sender} terlalu sering berkata kasar!\nJumlah pelanggaran: *${user.toxic}*\nBot akan mengeluarkanmu.`,
            mentions: [senderId]
          }, { quoted: m });

          await conn.groupParticipantsUpdate(m.chat, [senderId], 'remove');

          // 🔁 Reset setelah dikick
          updateUser(sender, { toxic: 0 });

        } else {
          await conn.sendMessage(m.chat, {
            text: `⚠️ @${sender} terlalu sering toxic (*${user.toxic}x*), tapi bot bukan admin jadi tidak bisa mengeluarkan.`,
            mentions: [senderId]
          }, { quoted: m });
        }
      } else {
        await conn.sendMessage(m.chat, {
          text: `⚠️ @${sender}, jangan berkata kasar!\nKamu sudah toxic *${user.toxic}/7* kali.`,
          mentions: [senderId]
        }, { quoted: m });
      }

      break; // Keluar dari loop setelah 1 toxic terdeteksi
    }
  }
} 
//🅰🅽🆃🅸🆂🆃🅸🅺🅴🆁 🅿🅴🅽🅶🅴🅲🅴🅺🅰🅽         // PENGECEKAN ANTISTIKER DI DALAM HANDLER UTAMA
if (m.isGroup && antiStickerStatus[m.chat]) {
  if (contentType === 'stickerMessage') {
    const groupMetadata = await conn.groupMetadata(m.chat);
    const participants = groupMetadata.participants;
    const senderId = conn.decodeJid(m.sender || m.key.participant || '');
    const isAdmin = participants.some(p => p.id === senderId && p.admin);

    if (!isAdmin) {
      await conn.sendMessage(m.chat, { delete: m.key });

      
      /*
      await conn.sendMessage(m.chat, {
        text: `⚠️ @${senderId.split('@')[0]}, dilarang kirim stiker!`,
        mentions: [senderId]
      }, { quoted: m });
      */
    }
  }
}
  
    
    
    
//72893929282728292929292
// 🅼🅴🅽🆄 🅵🅸🆃🆄🆁
if (command === '.menu') {
    if (m.isGroup === false) return;
  const senderJid = m.sender || m.key.participant || m.key.remoteJid || '';
  const sender = senderJid ? (conn.decodeJid(senderJid)?.split('@')[0] || '') : '';
  const user = getUser(sender);

  // 🔐 Cek daftar
  if (!user.nama || !user.umur) {
    return await conn.sendMessage(m.chat, {
      text: `
⚠️ Maaf, kamu belum terdaftar.

╭────〔 📋 *CARA DAFTAR* 〕──╮
│ ➤ Format : .daftar Nama,Umur
│ ➤ Contoh : .daftar Yus,17
╰──────────────────────╯

📌 Mengapa harus mendaftar?
• Bot kami memerlukan identitas dasar Anda.
• Pendaftaran memberi Anda akses ke fitur.
• Data Anda akan disimpan dengan aman.
`.trim()
    }, { quoted: m });
  }

    // ⏳ Kirim reaksi jam ke pesan user
await conn.sendMessage(m.chat, {
  react: {
    text: '⏳',
    key: m.key
  }
});
    
    
    
  // 📊 Ambil data
  const nama = user.nama;
  const umur = user.umur;
  const level = user.level;
  const uang = user.uang;
  const tiket = user.tiket || 10;
  const mode = global.isPublic ? 'ᴘᴜʙʟɪᴄ' : 'ꜱᴇʟꜰ';
  const isPremium = premium.includes(sender); // sender: 628xxxxxxx
const premiumStatus = isPremium ? '✅' : '❌';

  // 🖼️ Gambar dan thumbnail
  const thumb = fs.readFileSync('./image/thumbanil/thum1.jpg');

  // 📋 Menu text elegan
  const menuText = `
ʜᴀɪ \`${nama.toLowerCase()}\`
ɴᴀᴍᴀ ᴀᴋᴜ ᴀᴅᴀʟᴀʜ Syuzo Bot V2. 🤖
ᴀᴋᴜ ʙᴏᴛ ɢᴀᴍᴇ, ᴛᴀᴘɪ ʙɪꜱᴀ ᴜɴᴅᴜʜ ᴛɪᴋᴛᴏᴋ, ᴍᴘ3, ꜱᴛɪᴋᴇʀ ᴅꜱʙ.
ᴋʟᴀᴜ ᴇʀʀᴏʀ ʟᴀᴘᴏʀɪɴ ᴄʀᴇᴀᴛᴏʀ: 6283176775170 🙏

▫️ᴄʀᴇᴀᴛᴏʀ: Yuss Xy

╭──❍「 USER INFO 」❍
├ ɴᴀᴍᴀ    : ${nama}
├ ɪᴅ      : @${sender.replace(/[^0-9]/g, '')}
├ sᴛᴀᴛᴜꜱ  : Aktif
├ ᴛɪᴋᴇᴛ   : ${tiket}
├ ᴜᴀɴɢ    : ${uang}
├ ʟᴇᴠᴇʟ   : ${level}
├ ᴘʀᴇᴍɪᴜᴍ  : ${premiumStatus}
╰─┬────❍
╭─┴─❍「 ᴏᴡɴᴇʀ ɪɴꜰᴏ 」❍
├ ɴᴀᴍᴀ ʙᴏᴛ   : sʏᴜᴢᴏ ᴠ𝟸
├ ᴘᴏᴡᴇʀᴇᴅ ʙʏ : ʏᴜss xʏ
├ ᴏᴡɴᴇʀ      : ʏᴜss xʏ
├ ᴍᴏᴅᴇ       : ${mode}
├ ᴘʀᴇᴍɪᴜᴍ    : ${premiumStatus}
╰─┬────❍
╭─┴─❍「 ɢᴀᴍᴇ ᴍᴇɴᴜ 」❍
│ 1. .ᴍᴇ
│ 2. .claim
│ 3. .info
│ 4. .leaderboard
│ 5.
│ 6.
│ 7.
│ 8.
│ 9.
│ 10.
│ 11.
╰─┬────❍
╭─┴❍「 ᴄᴇᴋ ᴍᴇɴᴜ 」❍
│ 1. .ᴄᴇᴋᴊᴏᴅᴏʜ
│ 2. .ᴄᴇᴋᴍɪʀɪᴘ
│ 3. .ᴄᴇᴋᴍᴀᴛɪ
│ 4. .ʙɪsᴀᴋᴀʜ
│ 5. .ᴀᴘᴀᴋᴀʜ
│ 6. .ʀᴀᴛᴇ
╰─┬────❍
╭─┴❍「 ᴀᴅᴍɪɴ ᴍᴇɴᴜ 」❍
│ 1. .ᴀɴᴛɪʟɪɴᴋ ᴏɴ/ᴏғғ
│ 2. .ᴀɴᴛɪsᴛɪᴋᴇʀ ᴏɴ/ᴏғғ
│ 3. .ᴀɴᴛɪᴛᴏxɪᴄ ᴏɴ/ᴏғғ
│ 4. .sᴇᴛɴᴀᴍᴇɢᴄ
│ 5. .sᴇᴛᴘᴘɢᴄ
│ 6. .sᴇᴛᴅᴇsᴋ
│ 7. .ᴘʀᴏᴍᴏᴛᴇ
│ 8. .ᴅᴇᴍᴏᴛᴇ
│ 9. .ᴄʟᴏsᴇᴅɢᴄ
│ 10. .ᴏᴘᴇɴɢᴄ
│ 10. .ᴛᴀɢᴀʟʟ
│ 11. .ʜɪᴅᴇᴛᴀɢ
│ 12. .ᴛᴏᴛᴀɢ
│ 13. .ᴋɪᴄᴋ
│ 14. .ᴅᴏʀ
│ 15. .ᴅᴇʟ
╰─┬────❍
╭─┴❍「 ᴘʀᴇᴍɪᴜᴍ ᴍᴇɴᴜ 」❍
│ 1.
│ 2.
╰─┬────❍
╭─┴❍「 ᴏᴡɴᴇʀ ᴍᴇɴᴜ 」❍
│ 1. .addprem
│ 2. .delprem
│ 3. .listprem
╰──────❍
`.trim();

  // ⏬ Kirim pesan dengan tombol ke owner
  await conn.sendMessage(m.chat, {
    image: thumb,
    caption: menuText,
    footer: 'Syuzo V2 • Bot Menu',
    buttons: [
      {
        buttonId: '.owner',
        buttonText: { displayText: '👤 Hubungi Owner' },
        type: 1
      }
    ],
    headerType: 4
  }, { quoted: m });
    
   // ✅ Ubah reaksi jadi centang
await conn.sendMessage(m.chat, {
  react: {
    text: '✅',
    key: m.key
  }
});
    
}

    
//🅻🅴🅰🅳🅴🆁🅱🅾🅰🆁🅳🅳🅳🅳    
if (command === '.leaderboard' || command === '.ld') {
  if (!m.isGroup) return;

  const constOwner = '6283176775170'; // ganti dgn nomor owner kamu

  const topUsers = Object.entries(users)
    .filter(([id, user]) => user.nama && id !== constOwner)
    .sort((a, b) => b[1].uang - a[1].uang)
    .slice(0, 3);

  if (topUsers.length === 0) return m.reply('⚠️ Belum ada data leaderboard.');

  function toAesthetic(text) {
    const normal = 'abcdefghijklmnopqrstuvwxyz';
    const fancy = 'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀꜱᴛᴜᴠᴡxʏᴢ';
    return text.toLowerCase().split('').map(c => {
      const index = normal.indexOf(c);
      return index >= 0 ? fancy[index] : c;
    }).join('');
  }

  let teks = '╭─❏ │ 🏆 ' + toAesthetic('top 3 leaderboard uang terbesar') + '\n│\n';

  const medal = ['🥇', '🥈', '🥉'];

  for (let i = 0; i < topUsers.length; i++) {
    const [id, u] = topUsers[i];
    teks += `│ ${medal[i]} *${toAesthetic(u.nama)}*\n`;
    teks += `│     ↳ 💵 Rp${u.uang.toLocaleString()}\n`;
    teks += `│     ↳ ✨ Level ${u.level}\n`;
    teks += `│     ↳ ❤️ HP ${u.heal}\n│\n`;
  }

  teks += '╰───────────────────────────❏';

  return m.reply(teks);
} 
  
    
    
//🅸🅽🅵🅾🅾🅾 🅲🅴🅺🅺🅺    
if (command.startsWith('.info')) {
  if (!m.isGroup) return m.reply('⚠️ Fitur ini hanya bisa digunakan di dalam grup.');

  const user = getUser(sender);
  if (!user.nama) {
    return m.reply(`🔒 Kamu belum terdaftar.

╭────〔 📋 \`CARA DAFTAR\` 〕
│ ➤ Format : .daftar Nama,Umur
│ ➤ Contoh : .daftar Yus,17
╰─────────────────────⭓

*Daftar dulu untuk menggunakan fitur ini*`);
  }

  const context = m.message?.extendedTextMessage?.contextInfo || {};
  const mentionedJid = context.mentionedJid?.[0] || m.mentionedJid?.[0];

  console.log('MentionedJid:', mentionedJid); // ← debug di sini

  if (!mentionedJid) {
    return m.reply(`⚠️ Tag seseorang untuk melihat profilnya.\nContoh: *.info @tag*`);
  }

  const targetId = mentionedJid.split('@')[0];
  const target = getUser(targetId);

  if (!target.nama) {
    return m.reply('❌ Pengguna tersebut belum mendaftar.');
  }

  const xpNeeded = 100 * target.level; // contoh rumus xp

  const profil = `
╭──〔 👤 PROFIL ORANG 〕───⭓
│ 📛 Nama     : *${target.nama}*
│ 🎂 Umur     : *${target.umur || '–'}*
│
│ 💰 Uang     : *Rp ${target.uang.toLocaleString()}*
│ ⭐ Level    : *${target.level}* (*${target.xp}/${xpNeeded}*)
│ ⚡ Stamina  : *${target.stamina}*
│ 🔖 Limit    : *${target.limit}*
│ 🎟️ Tiket    : *${target.tiket || 0}*
│ ❤️ HP       : *${target.heal}*
╰─────────────────────⭓
`.trim();

  return m.reply(profil);
}
  
  
 

  
    


  
//🅲🅻🅰🅸🅼🅼🅼🅼    
 if (command.startsWith('.claim')) {
     if (m.isGroup === false) return;
  const sender = senderJid.replace(/[^0-9]/g, '');
  const user = getUser(sender);

  if (!user.nama) {
    return m.reply(`🔒 Kamu belum terdaftar.

╭────〔 📋 \`CARA DAFTAR\` 〕
│ ➤ Ketik: *.daftar*
╰─────────────────────⭓`);
  }

  const now = Date.now();
  const cooldown = 20 * 60 * 60 * 1000; // 20 jam dalam milidetik
  const lastClaim = user.lastClaim || 0;
  const remaining = cooldown - (now - lastClaim);

  if (remaining > 0) {
    const jam = Math.floor(remaining / (1000 * 60 * 60));
    const menit = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));
    const detik = Math.floor((remaining % (1000 * 60)) / 1000);
    return m.reply(`⏳ Kamu sudah klaim.\nCoba lagi dalam *${jam} jam ${menit} menit ${detik} detik*.`);
  }

  // Berikan hadiah harian
  user.uang += 10000;
  user.xp += 50;
  user.limit += 5;
  user.tiket = (user.tiket || 0) + 5;
  user.lastClaim = now;

  updateUser(sender, user);

  return m.reply(`🎁 *Claim Harian*

+💵 Uang: 10.000
+✨ XP: 50
+🔖 Limit: 5
+🎟 Tiket: 5

claim lagi besok ya✨`);
}
  
   
 

  

    

    
//🅺🅴🆁🅰🅽🅶 🅰🅹🅰🅸🅱🅱🅱  
if (command.startsWith('.bisakah')) {
    if (m.isGroup === false) return;
  // Cek apakah user sudah terdaftar
  if (!user.nama) {
    return conn.sendMessage(m.chat, {
      text: `⚠️ Maaf, kamu belum terdaftar.

╭────〔 📋 \`CARA DAFTAR\` 〕──╮
│ ➤ Format : .daftar Nama,Umur
│ ➤ Contoh : .daftar Yus,17
╰──────────────────────╯

📌 Mengapa harus mendaftar?
• Bot kami memerlukan identitas dasar Anda.
• Pendaftaran memberi akses ke fitur.
• Data Anda aman dan hanya untuk bot.
`,
      quoted: m
    });
  }

  // Ambil pertanyaan
  const args = text.trim().split(/\s+/).slice(1); // Buang '.bisakah'
  const pertanyaan = args.join(' ');

  if (!pertanyaan) {
    return m.reply('❓ Contoh: *.bisakah aku jadi kaya*');
  }

  // Daftar jawaban acak
  const jawabanAcak = [
    'Iya mungkin ✅',
    'Ngarep lu 🗿',
    'Tidak mungkin',
    'Sangat mungkin',
    'Tidak akan',
    'itu pasti',
    'Ya 👍'
  ];

  const hasil = jawabanAcak[Math.floor(Math.random() * jawabanAcak.length)];
  const mention = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : senderJid;

  const teks = `╭─〔 🔮 *BISAKAH CEK* 〕─⭓
│ 👤 Penanya : @${sender}
│ ❓ Pertanyaan :
│  • Bisakah ${pertanyaan}?
│
│ 💬 Jawaban :
│  *${hasil}*
╰───────────────⭓`;

  return await conn.sendMessage(m.chat, {
    text: teks,
    mentions: [mention]
  }, { quoted: m });
}
  
//🅰🅿🅰🅺🅰🅷
 if (command.startsWith('.apakah')) {
     if (m.isGroup === false) return;
  // Cek apakah user sudah daftar
  if (!user.nama) {
    return await conn.sendMessage(m.chat, {
      text: `⚠️ Kamu belum terdaftar kak!

╭────〔 📋 \`CARA DAFTAR\` 〕─────⭓
│ ➤ Format : .daftar Nama,Umur
│ ➤ Contoh : .daftar Yus,17
╰────────────────────────────⭓

📌 Kenapa harus daftar?
• Akses ke semua fitur bot
• Datamu aman dan privat 🛡️
• Bisa ngumpulin uang, xp, level, dll!
`,
      quoted: m // <== PENTING! reply ke pesan user
    });
  }

  // Ambil teks pertanyaan
  const args = text.trim().split(/\s+/).slice(1);
  const pertanyaan = args.join(' ');

  if (!pertanyaan) {
    return m.reply('Contoh: *.apakah aku jodohnya dia*');
  }

  // Jawaban receh random
  const jawabanReceh = [
    'Ngarep banget lu suqi 🗿',
    'Kemungkinan ada, tapi kayaknya kecil sih 🗿',
    'Lu kira gampang? mikir dek 🗿',
    'Nggak akan bisa kalo skill cuma rebahan 🗿',
    'Jangan ngimpi dulu, bangun dulu dari kasur 🗿',
    'Bisa sih... kalo dunia ini fiksi 🗿',
    'Ah lu mah ngarep teruss🗿',
    'Kemungkinannya sangat kecil',
    'Mana saya tau 🗿',
    'Iyaa'
      
  ];

  const hasil = jawabanReceh[Math.floor(Math.random() * jawabanReceh.length)];

  const teks = `╭──〔 🧠 *APAKAH CEK* 〕──⭓
│ 📍 Pertanyaan :
│  • Apakah ${pertanyaan}?
│
│ 🤖 Jawaban :
│  *${hasil}*
╰──────────────────────⭓`;

  await conn.sendMessage(m.chat, {
    text: teks,
    mentions: [senderJid]
  }, { quoted: m });
}
 
//🆁🅰🆃🅴🅴🅴🅴🅴    
if (command.startsWith('.rate')) {
  if (!m.isGroup) return m.reply('❌ Fitur ini hanya bisa digunakan di grup.');

  const userData = getUser(sender);
  if (!userData?.nama) {
    return await conn.sendMessage(m.chat, {
      text: `🔒 Kamu belum terdaftar.

╭────〔 📋 \`CARA DAFTAR\` 〕
│ ➤ Format : .daftar Nama,Umur
│ ➤ Contoh : .daftar Yus,17
╰─────────────────────⭓

*Daftar dulu untuk menggunakan fitur .rate!*`,
      quoted: m
    });
  }

  const targetId = m.mentionedJid?.[0];
  const isTag = !!targetId;
  const targetText = args.slice(1).join(' ');
  if (!targetText) return m.reply('⚠️ Contoh penggunaan:\n.rate baju aku\n.rate fotonya @user');

  const displayTarget = isTag
    ? getUser(conn.decodeJid(targetId).split('@')[0])?.nama
      ? `@${getUser(conn.decodeJid(targetId).split('@')[0]).nama}`
      : targetText.match(/@\S+/)?.[0] || 'orang ini'
    : targetText;

  const rating = Math.floor(Math.random() * 100) + 1;

  const hasil = `╭─❍「 🎯 HASIL PENILAIAN 」
│ ✨ Subjek : *Rate ${displayTarget}*
│ 💯 Nilai : *${rating}%*
╰────────────────────⭓`;

  await conn.sendMessage(m.chat, {
    text: hasil,
    mentions: isTag ? [targetId] : [senderJid]
  }, { quoted: m });
}    
    
  
//🅲🅴🅺🅹🅾🅳🅾🅷🅷🅷🅷    
 if (command.startsWith('.cekjodoh')) {
  if (!m.isGroup) return m.reply('❌ Fitur ini hanya bisa digunakan di grup.');

  // Cek apakah user sudah terdaftar
  const userData = getUser(sender);
  if (!userData?.nama) {
    return await conn.sendMessage(m.chat, {
      text: `🔒 Kamu belum terdaftar.

╭────〔 📋 \`CARA DAFTAR\` 〕
│ ➤ Format : .daftar Nama,Umur
│ ➤ Contoh : .daftar Yus,17
╰─────────────────────⭓

*Daftar dulu untuk menggunakan fitur .cekjodoh!*`,
      quoted: m
    });
  }

  // Ambil input nama atau mention
  const input = args.slice(1).join(' ') || '';
  const taggedUser = m.mentionedJid?.[0];
  const targetName = taggedUser
    ? '@' + taggedUser.split('@')[0]
    : input || '@' + sender;

  // Ambil peserta grup, selain pengirim
  const groupMetadata = await conn.groupMetadata(m.chat);
  const participants = groupMetadata.participants
    .map(p => p.id)
    .filter(id => id !== senderJid);

  if (participants.length === 0) {
    return m.reply('❌ Tidak ditemukan anggota grup lain selain kamu.');
  }

  // Pilih jodoh acak
  const jodohId = participants[Math.floor(Math.random() * participants.length)];
  const jodohTag = '@' + jodohId.split('@')[0];

  const hasil = `
💘 *CEK JODOH GAME* 💘

╭─❏
│ 👤 Di Cek : *${targetName}*
│ 💞 Jodohnya: *${jodohTag}*
╰─❏

✨ Nikahin aja Njing 🗿
`;

  await conn.sendMessage(m.chat, {
    text: hasil,
    mentions: [senderJid, jodohId],
  }, { quoted: m });
}  
    
//🅲🅴🅺🅺 🅼🅰🆃🅸🅸🅸🅸    
  if (command.startsWith('.cekmati')) {
  if (!m.isGroup) return m.reply('❌ Fitur ini hanya bisa digunakan di grup.');

  // Cek apakah user sudah terdaftar
  const userData = getUser(sender);
  if (!userData?.nama) {
    return await conn.sendMessage(m.chat, {
      text: `🔒 Kamu belum terdaftar.

╭────〔 📋 \`CARA DAFTAR\` 〕
│ ➤ Format : .daftar Nama,Umur
│ ➤ Contoh : .daftar Yus,17
╰─────────────────────⭓

*Daftar dulu untuk menggunakan fitur .cekmati!*`,
      quoted: m
    });
  }

  const input = args.slice(1).join(' ') || '';
  const taggedUser = m.mentionedJid?.[0];
  const target =
    taggedUser
      ? '@' + taggedUser.split('@')[0]
      : input || '@' + sender;

  const umurMati = Math.floor(Math.random() * (65 - 20 + 1)) + 20;

  const hasil = `
☠️ *CEK KEMATIAN* ☠️

╭─❏
│ 💀 Orang   : *${target}*
│ ⏳ Mati di usia : *${umurMati} tahun*
╰─❏

🪦 Jangan lupa tobat bro 👍
`;

  await conn.sendMessage(m.chat, {
    text: hasil,
    mentions: taggedUser ? [taggedUser] : [senderJid]
  }, { quoted: m });
}  
    
    
    
 //🅲🅴🅺🅺🅺🅺 🅼🅸🆁🅸🅿🅿🅿🅿   
if (command.startsWith('.cekmirip')) {
  if (!m.isGroup) return m.reply('❌ Fitur ini hanya bisa digunakan di grup.');

  const userData = getUser(sender);
  if (!userData?.nama) {
    return await conn.sendMessage(m.chat, {
      text: `🔒 Kamu belum terdaftar.

╭────〔 📋 \`CARA DAFTAR\` 〕
│ ➤ Format : .daftar Nama,Umur
│ ➤ Contoh : .daftar Yus,17
╰─────────────────────⭓

*Daftar dulu untuk menggunakan fitur .cekmirip!*`,
      quoted: m
    });
  }

  if (userData.limit <= 0) {
    return m.reply(`💸 Limit kamu habis!\nSilakan tunggu reset harian atau beli limit.`);
  }

  const genderInput = args[1]?.toUpperCase();
  const isTag = !!m.mentionedJid?.[0];
  const targetId = isTag ? conn.decodeJid(m.mentionedJid[0]) : null;
  const targetName = args.slice(2).join(' ');

  if (!['L', 'C'].includes(genderInput) || (!isTag && !targetName)) {
    return m.reply('⚠️ Gunakan format:\n.cekmirip L nama/@tag\n.cekmirip C nama/@tag');
  }

  const getRawTagText = () => {
    const match = text.match(/@(\S+)/);
    return match ? `@${match[1]}` : targetName;
  };

  let displayName;
  if (isTag) {
    const userDB = getUser(targetId?.split('@')[0]);
    displayName = userDB?.nama ? `@${userDB.nama}` : getRawTagText();
  } else {
    displayName = targetName;
  }

  const folder = genderInput === 'L' ? 'laki' : 'cewe';
  const num = Math.floor(Math.random() * 20) + 1;
  const imagePath = `./image/cekmirip/${folder}/${folder}${num}.jpg`;
  const persen = (Math.random() * (99.9 - 85.5) + 85.5).toFixed(1);

  await conn.sendMessage(m.chat, {
    image: { url: imagePath },
    caption: `🎯 *Hasil Pencocokan Wajah*

📸 Berdasarkan analisa, *${displayName}* memiliki kemiripan dengan orang ini!

🎭 Persentase mirip: *${persen}%* 😄`,
    mentions: isTag ? [targetId] : [senderJid]
  }, { quoted: m });

  // Kurangi limit diam-diam
  userData.limit -= 1;
  updateUser(sender, userData);
}
  
  

    
    
    
    
    
//=================================//
//🅰🅳🅼🅸🅽 🅵🅸🆃🆄🆁🆁🆁🆁🆁   
 //🅰🅽🆃🅸🆂🆃🅸🅺🅴🆁 🅾🅽/🅾🅵🅵   
   if (command.startsWith('.antistiker') && m.isGroup) {
  const groupMetadata = await conn.groupMetadata(m.chat);
  const participants = groupMetadata.participants;

  const senderId = conn.decodeJid(m.sender || m.key.participant || '');
  const isAdmin = participants.some(p => p.id === senderId && p.admin);

  if (!isAdmin) return m.reply('❌ Hanya *admin grup* yang bisa mengatur fitur AntiSticker.');

  const arg = text.split(' ')[1]?.toLowerCase();
  if (!['on', 'off'].includes(arg)) {
    return m.reply('⚙️ Gunakan:\n.antistiker on\n.antistiker off');
  }

  if (arg === 'on') {
    antiStickerStatus[m.chat] = true;
    saveAntiSticker();
    return m.reply('✅ AntiSticker telah *diaktifkan*.');
  } else {
    delete antiStickerStatus[m.chat];
    saveAntiSticker();
    return m.reply('✅ AntiSticker telah *dinonaktifkan*.');
  }
}
    
    
    
 //🅰🅽🆃🅸🆃🅾🆇🅸🅲🅲🅲🅲🅲🅲🅲   
   if (command.startsWith('.antitoxic') && m.isGroup) {
  const groupMetadata = await conn.groupMetadata(m.chat);
  const participants = groupMetadata.participants;

  const senderId = conn.decodeJid(m.sender || m.key.participant || '');
  const isAdmin = participants.some(p => p.id === senderId && p.admin);

  if (!isAdmin) {
    return m.reply('❌ Hanya *admin grup* yang bisa mengatur fitur AntiToxic.');
  }

  const arg = text.split(' ')[1]?.toLowerCase();
  if (!['on', 'off'].includes(arg)) {
    return m.reply('⚙️ Gunakan:\n.antitoxic on\n.antitoxic off');
  }

  if (arg === 'on') {
    antiToxicStatus[m.chat] = true;
    saveAntiToxic();
    return m.reply('✅ AntiToxic telah *diaktifkan*.');
  } else {
    delete antiToxicStatus[m.chat];
    saveAntiToxic();
    return m.reply('✅ AntiToxic telah *dinonaktifkan*.');
  }
}
    
    
    
    
    
//🅰🅽🆃🅸🅻🅸🅽🅺
 // 🛡️ .antilink on
if (command === '.antilink on' && m.isGroup) {
  const groupMetadata = await conn.groupMetadata(m.chat);
  const participants = groupMetadata.participants;

  const senderId = conn.decodeJid(m.sender || m.key.participant || '');
  const botNumber = conn.user?.id?.split(':')[0]?.replace(/\D/g, '') + '@s.whatsapp.net';

  const isAdmin = participants.some(p => p.id === senderId && p.admin);
  const isBotAdmin = participants.some(p => p.id === botNumber && p.admin);

  if (!isAdmin) return m.reply('❌ Hanya *admin grup* yang bisa mengaktifkan antilink.');
  if (!isBotAdmin) return m.reply('❌ Bot harus jadi *admin grup* dulu.');

  antilinkData[m.chat] = true;
  saveAntilink();
  m.reply('✅ Antilink telah *diaktifkan*.');
}

// ❌ .antilink off
if (command === '.antilink off' && m.isGroup) {
  const groupMetadata = await conn.groupMetadata(m.chat);
  const participants = groupMetadata.participants;

  const senderId = conn.decodeJid(m.sender || m.key.participant || '');
  const botNumber = conn.user?.id?.split(':')[0]?.replace(/\D/g, '') + '@s.whatsapp.net';

  const isAdmin = participants.some(p => p.id === senderId && p.admin);
  const isBotAdmin = participants.some(p => p.id === botNumber && p.admin);

  if (!isAdmin) return m.reply('❌ Hanya *admin grup* yang bisa menonaktifkan antilink.');
  if (!isBotAdmin) return m.reply('❌ Bot harus jadi *admin grup* dulu.');

  delete antilinkData[m.chat];
  saveAntilink();
  m.reply('✅ Antilink telah *dinonaktifkan*.');
}

  
  
  
  

  


  

  
  

  
  
  

  
 
    
    
    
    
//🅳🅾🆁🆁🆁🆁🆁    
    if (command === '.dor' && m.isGroup) {
  const groupMetadata = await conn.groupMetadata(m.chat);
  const participants = groupMetadata.participants;

  const senderId = conn.decodeJid(m.sender || m.key.participant || '');
  const botNumber = conn.user?.id?.split(':')[0]?.replace(/\D/g, '') + '@s.whatsapp.net';

  const isAdmin = participants.some(p => p.id === senderId && p.admin);
  const isBotAdmin = participants.some(p => p.id === botNumber && p.admin);

  if (!isAdmin) {
    return conn.sendMessage(m.chat, {
      text: '❌ Hanya *admin grup* yang bisa menggunakan perintah ini.',
    }, { quoted: m });
  }

  if (!isBotAdmin) {
    return conn.sendMessage(m.chat, {
      text: '❌ Bot harus jadi *admin grup* dulu.',
    }, { quoted: m });
  }

  // Ambil target dari pesan yang di-reply
  const quotedMsg = m.message?.extendedTextMessage?.contextInfo;
  const target = quotedMsg?.participant;

  if (!target) {
    return conn.sendMessage(m.chat, {
      text: '⚠️ Balas pesan user yang ingin dikeluarkan dengan ketik *.dor*',
    }, { quoted: m });
  }

  try {
    await conn.groupParticipantsUpdate(m.chat, [target], 'remove');
    await conn.sendMessage(m.chat, {
      text: `💥 @${target.split('@')[0]} telah didor keluar dari grup.`,
      mentions: [target]
    }, { quoted: m });
  } catch (e) {
    await conn.sendMessage(m.chat, {
      text: '❌ Gagal dor. Pastikan user masih di grup dan bot memiliki izin.',
    }, { quoted: m });
  }
}
    
  //🅺🅸🅲🅺🅺🅺🅺🅺🅺  
   if (command.startsWith('.kick') && m.isGroup) {
  const groupMetadata = await conn.groupMetadata(m.chat);
  const participants = groupMetadata.participants;

  const senderId = conn.decodeJid(m.sender || m.key.participant || '');
  const botNumber = conn.user?.id?.split(':')[0]?.replace(/\D/g, '') + '@s.whatsapp.net';

  const isAdmin = participants.some(p => p.id === senderId && p.admin);
  const isBotAdmin = participants.some(p => p.id === botNumber && p.admin);

  if (!isAdmin) {
    return conn.sendMessage(m.chat, {
      text: '❌ Hanya *admin grup* yang bisa mengeluarkan member.',
    }, { quoted: m });
  }

  if (!isBotAdmin) {
    return conn.sendMessage(m.chat, {
      text: '❌ Bot harus jadi *admin grup* dulu.',
    }, { quoted: m });
  }

  let target;
  const mention = m.message?.extendedTextMessage?.contextInfo?.mentionedJid;
  if (mention && mention.length > 0) {
    target = mention[0];
  } else {
    const number = text.split(' ')[1]?.replace(/\D/g, '');
    if (!number) {
      return conn.sendMessage(m.chat, {
        text: '⚠️ Tag atau ketik nomor yang ingin dikick.\nContoh: *.kick @tag* atau *.kick 628xxxxxx*'
      }, { quoted: m });
    }
    target = number + '@s.whatsapp.net';
  }

  try {
    await conn.groupParticipantsUpdate(m.chat, [target], 'remove');
    await conn.sendMessage(m.chat, {
      text: `👢 @${target.split('@')[0]} telah dikeluarkan dari grup.`,
      mentions: [target]
    }, { quoted: m });
  } catch (e) {
    await conn.sendMessage(m.chat, {
      text: '❌ Gagal kick. Pastikan user masih di grup dan bot memiliki izin.',
    }, { quoted: m });
  }
}
    
 
 //🅳🅴🅻🅻🅻🅻🅻🅻🅻🅻   
if ((command.startsWith('.del') || command.startsWith('.dell')) && m.isGroup) {
  const groupMetadata = await conn.groupMetadata(m.chat);
  const participants = groupMetadata.participants;

  const senderId = conn.decodeJid(m.sender || m.key.participant || '');
  const botNumber = conn.user?.id?.split(':')[0]?.replace(/\D/g, '') + '@s.whatsapp.net';

  const isAdmin = participants.some(p => p.id === senderId && p.admin);
  const isBotAdmin = participants.some(p => p.id === botNumber && p.admin);

  if (!isAdmin || !isBotAdmin) return;

  const quotedMsg = m.message?.extendedTextMessage?.contextInfo;
  const quotedId = quotedMsg?.stanzaId;
  const quotedParticipant = quotedMsg?.participant;

  if (!quotedId || !quotedParticipant) {
    return conn.sendMessage(m.chat, {
      text: '⚠️ Balas pesan yang ingin dihapus dengan *.del*',
    }, { quoted: m });
  }

  try {
    await conn.sendMessage(m.chat, {
      delete: {
        remoteJid: m.chat,
        fromMe: false,
        id: quotedId,
        participant: quotedParticipant
      }
    });
  } catch {
    // Error dibungkam agar tidak spam log/console
  }
}

  
  
        

  
    
    
    
    
    
 //🅿🆁🅾🅼🅾🆃🅴🅴🅴🅴🅴🅴   
if (command.startsWith('.promote') && m.isGroup) {
  const groupMetadata = await conn.groupMetadata(m.chat);
  const participants = groupMetadata.participants;

  const senderId = conn.decodeJid(m.sender || m.key.participant || '');
  const botNumber = conn.user?.id?.split(':')[0]?.replace(/\D/g, '') + '@s.whatsapp.net';

  const isAdmin = participants.some(p => p.id === senderId && p.admin);
  const isBotAdmin = participants.some(p => p.id === botNumber && p.admin);

  console.log('🔍 Sender:', senderId);
  console.log('🤖 Bot Number:', botNumber);
  console.log('🛡️ isAdmin:', isAdmin);
  console.log('🛡️ isBotAdmin:', isBotAdmin);

  if (!isAdmin) {
    return conn.sendMessage(m.chat, {
      text: '❌ Hanya *admin grup* yang bisa mempromosikan member.'
    }, { quoted: m });
  }

  if (!isBotAdmin) {
    return conn.sendMessage(m.chat, {
      text: '❌ Bot harus jadi *admin grup* dulu.'
    }, { quoted: m });
  }

  let target;
  const mention = m.message?.extendedTextMessage?.contextInfo?.mentionedJid;
  if (mention && mention.length > 0) {
    target = mention[0];
  } else {
    const number = text.split(' ')[1]?.replace(/\D/g, '');
    if (!number) {
      return conn.sendMessage(m.chat, {
        text: '⚠️ Tag atau ketik nomor yang ingin dipromote.\nContoh: *.promote @tag* atau *.promote 628xxxxxx*'
      }, { quoted: m });
    }
    target = number + '@s.whatsapp.net';
  }

  try {
    await conn.groupParticipantsUpdate(m.chat, [target], 'promote');
    await conn.sendMessage(m.chat, {
      text: `╭─❍「 🆙 *PROMOTE BERHASIL* 」❍\n│ ✅ @${target.split('@')[0]} sekarang *admin grup*\n╰──>`,
      mentions: [target]
    }, { quoted: m });
  } catch (e) {
    console.log('❌ Error saat promote:', e);
    await conn.sendMessage(m.chat, {
      text: '❌ Gagal promote. Pastikan user masih di grup dan bot memiliki izin.',
    }, { quoted: m });
  }
}
  
    


    
    
    
    
 if (command.startsWith('.demote') && m.isGroup) {
  const groupMetadata = await conn.groupMetadata(m.chat);
  const participants = groupMetadata.participants;

  const senderId = conn.decodeJid(m.sender || m.key.participant || '');
  const botNumber = conn.user?.id?.split(':')[0]?.replace(/\D/g, '') + '@s.whatsapp.net';

  const isAdmin = participants.some(p => p.id === senderId && p.admin);
  const isBotAdmin = participants.some(p => p.id === botNumber && p.admin);

  console.log('🔍 Sender:', senderId);
  console.log('🤖 Bot Number:', botNumber);
  console.log('🛡️ isAdmin:', isAdmin);
  console.log('🛡️ isBotAdmin:', isBotAdmin);

  if (!isAdmin) {
    return conn.sendMessage(m.chat, { text: '❌ Hanya *admin grup* yang bisa menurunkan pangkat member.' }, { quoted: m });
  }

  if (!isBotAdmin) {
    return conn.sendMessage(m.chat, { text: '❌ Bot harus jadi *admin grup* dulu.' }, { quoted: m });
  }

  let target;
  const mention = m.message?.extendedTextMessage?.contextInfo?.mentionedJid;
  if (mention && mention.length > 0) {
    target = mention[0];
  } else {
    const number = text.split(' ')[1]?.replace(/\D/g, '');
    if (!number) {
      return conn.sendMessage(m.chat, {
        text: '⚠️ Tag atau ketik nomor yang ingin didemote.\nContoh: *.demote @tag* atau *.demote 628xxxxxx*'
      }, { quoted: m });
    }
    target = number + '@s.whatsapp.net';
  }

  try {
    await conn.groupParticipantsUpdate(m.chat, [target], 'demote');
    await conn.sendMessage(m.chat, {
      text: `╭─❍「 🔽 *DEMOTE BERHASIL* 」❍\n│ ❌ @${target.split('@')[0]} sekarang *bukan admin*\n╰────`,
      mentions: [target]
    }, { quoted: m });
  } catch (e) {
    console.log('❌ Error saat demote:', e);
    await conn.sendMessage(m.chat, {
      text: '❌ Gagal demote. Pastikan user masih di grup dan bot memiliki izin.',
    }, { quoted: m });
  }
}
    

 
    
    
  //🆂🅴🆃 🅿🅿 🅶🅲  

  // 🖼️ SETPPGC - Ganti foto profil grup (khusus admin & reply gambar)
if (command === '.setppgc') {
  if (!m.isGroup) return;

  try {
    const groupMetadata = await conn.groupMetadata(m.chat);
    const participants = groupMetadata.participants;
    
    const senderJid = m.sender || m.key.participant || m.key.remoteJid || '';
    const senderId = conn.decodeJid(senderJid);
    const isAdmin = participants.some(p => p.id === senderId && (p.admin === 'admin' || p.admin === 'superadmin'));

    if (!isAdmin) {
      return await conn.sendMessage(m.chat, {
        text: '❌ Hanya admin yang bisa mengubah foto grup.',
      }, { quoted: m });
    }

    // Ambil gambar dari reply atau langsung kiriman
    const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const imgMsg = quoted?.imageMessage || m.message?.imageMessage;
    if (!imgMsg) {
      return await conn.sendMessage(m.chat, {
        text: '⚠️ Kirim atau reply gambar dengan caption *.setppgc* untuk mengganti foto grup.',
      }, { quoted: m });
    }

    // Unduh gambar
    const stream = await downloadContentFromMessage(imgMsg, 'image');
    let buffer = Buffer.from([]);
    for await (const chunk of stream) {
      buffer = Buffer.concat([buffer, chunk]);
    }

    // Update foto grup
    await conn.updateProfilePicture(m.chat, buffer);
    await conn.sendMessage(m.chat, {
      text: '✅ Foto profil grup berhasil diubah!',
    }, { quoted: m });

  } catch (err) {
    console.error('❌ Error setppgc:', err);
    await conn.sendMessage(m.chat, {
      text: '⚠️ Terjadi kesalahan saat mengubah foto grup pastikan bot adalah admin grup.',
    }, { quoted: m });
  }
}
    

  
  
    
    
    
// 🌐 TAGALL - Mention semua anggota grup
if (command === '.tagall') {
  if (m.isGroup === false) return;
   
  const groupMetadata = await conn.groupMetadata(m.chat);
  const participants = groupMetadata.participants;
  const senderId = conn.decodeJid(m.sender || m.key.participant || '');
  const isAdmin = participants.find(p => p.id === senderId)?.admin;

  if (!isAdmin) {
    return await conn.sendMessage(m.chat, {
      text: '❌ Hanya admin yang bisa menggunakan perintah ini.',
    }, { quoted: m });
  }

  let tagText = `👥 *Tag Semua Member*\n\n`;
  let mentions = [];

  for (let p of participants) {
    const id = p.id;
    tagText += `⪼ @${id.split('@')[0]}\n`;
    mentions.push(id);
  }

  await conn.sendMessage(m.chat, {
    text: tagText,
    mentions
  }, { quoted: m });
}

 
//🅷🅸🅳🅴🆃🅰🅶🅶🅶
// 🙈 HIDETAG - Mention semua member tanpa terlihat (khusus admin)
if (command.startsWith('.hidetag') || command.startsWith('.h')) {
  if (m.isGroup === false) return;

  const groupMetadata = await conn.groupMetadata(m.chat);
  const participants = groupMetadata.participants;
  const senderId = conn.decodeJid(m.sender || m.key.participant || '');
  const isAdmin = participants.find(p => p.id === senderId)?.admin;

  if (!isAdmin) {
    return await conn.sendMessage(m.chat, {
      text: '❌ Hanya admin yang bisa menggunakan perintah ini.',
    }, { quoted: m });
  }

  const isiPesan = text?.split(' ').slice(1).join(' ').trim();

  if (!isiPesan) {
    return await conn.sendMessage(m.chat, {
      text: `
❌ Kamu belum menulis pesannya!

📌 Contoh penggunaan:
.hidetag Assalamualaikum
.h Halo semua 🗿

`.trim()
    }, { quoted: m });
  }

  const mentions = participants.map(p => p.id);

  await conn.sendMessage(m.chat, {
    text: isiPesan,
    mentions
  }, { quoted: m });
}
    
  //🆃🅾🆃🅰🅶🅶🅶🅶🅶
// 📣 TOTAG - Kirim ulang isi pesan reply dan mention semua member
if (command === '.totag') {
  if (!m.isGroup) return;

  const groupMetadata = await conn.groupMetadata(m.chat);
  const participants = groupMetadata.participants;
  const senderId = conn.decodeJid(m.sender || m.key.participant || '');
  const isAdmin = participants.find(p => p.id === senderId)?.admin;

  if (!isAdmin) {
    return await conn.sendMessage(m.chat, {
      text: '❌ Hanya admin yang bisa menggunakan perintah ini.',
    }, { quoted: m });
  }

  const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
  if (!quoted) {
    return await conn.sendMessage(m.chat, {
      text: '❌ Balas pesan yang ingin kamu tag ulang.',
    }, { quoted: m });
  }

  // Ambil isi teks dari berbagai jenis pesan yang di-reply
  const contentTypes = ['conversation', 'extendedTextMessage', 'imageMessage', 'videoMessage', 'documentMessage'];
  let isi = '';

  for (const type of contentTypes) {
    if (quoted[type]) {
      isi = quoted[type].text || quoted[type].caption || quoted[type].description || '';
      break;
    }
  }

  if (!isi) isi = '[📎 Media]';

  const mentions = participants.map(p => p.id);

  await conn.sendMessage(m.chat, {
    text: isi,
    mentions
  }, { quoted: m });
}
//🅾🅿🅴🅽 🅶🅲
if (['.opengc', '.bukagc'].includes(command)) {
  if (!m.isGroup) return;

  const groupMetadata = await conn.groupMetadata(m.chat);
  const participants = groupMetadata.participants;

  const senderId = conn.decodeJid(m.sender || m.key.participant || '');
  const isAdmin = participants.find(p => p.id === senderId)?.admin;

  const botId = conn.decodeJid(conn.user.id);
  const isBotAdmin = participants.find(p => p.id === botId)?.admin;

  if (!isAdmin) {
    return await conn.sendMessage(m.chat, {
      text: '❌ Hanya admin yang bisa membuka grup.',
    }, { quoted: m });
  }

  if (!isBotAdmin) {
    return await conn.sendMessage(m.chat, {
      text: '⚠️ Bot bukan admin, tidak bisa membuka grup.',
    }, { quoted: m });
  }

  await conn.groupSettingUpdate(m.chat, 'not_announcement'); // Semua bisa kirim
  await conn.sendMessage(m.chat, {
    text: '✅ Grup berhasil *dibuka*. Semua anggota bisa mengirim pesan.',
  }, { quoted: m });
}
  

//🅲🅻🅾🆂🅴🅳 🅶🅲
if (['.closegc', '.closedgc', '.tutupgc'].includes(command)) {
  if (!m.isGroup) return;

  const groupMetadata = await conn.groupMetadata(m.chat);
  const participants = groupMetadata.participants;

  const senderId = conn.decodeJid(m.sender || m.key.participant || '');
  const isAdmin = participants.find(p => p.id === senderId)?.admin;
  const botId = conn.decodeJid(conn.user.id);
  const isBotAdmin = participants.find(p => p.id === botId)?.admin;

  if (!isAdmin) {
    return await conn.sendMessage(m.chat, {
      text: '❌ Hanya admin yang bisa menutup grup.',
    }, { quoted: m });
  }

  if (!isBotAdmin) {
    return await conn.sendMessage(m.chat, {
      text: '⚠️ Bot bukan admin, tidak bisa menutup grup.',
    }, { quoted: m });
  }

  await conn.groupSettingUpdate(m.chat, 'announcement'); // Hanya admin bisa kirim
  await conn.sendMessage(m.chat, {
    text: '✅ Grup berhasil *ditutup*. Sekarang hanya admin yang bisa mengirim pesan.'
  }, { quoted: m });
}
    
//🆂🅴🆃🆃🆃 🅽🅰🅼🅴🅴🅴 🅶🅲
  // ✏️ SETNAMEGC - Ganti nama grup (khusus admin)
if (command.startsWith('.setnamegc')) {
  if (m.isGroup === false) return;

  const groupMetadata = await conn.groupMetadata(m.chat);
  const participants = groupMetadata.participants;
  const senderId = conn.decodeJid(m.sender || m.key.participant || '');
  const isAdmin = participants.find(p => p.id === senderId)?.admin;

  if (!isAdmin) {
    return await conn.sendMessage(m.chat, {
      text: '❌ Hanya admin yang bisa mengganti nama grup.',
    }, { quoted: m });
  }

  const newName = text?.split(' ').slice(1).join(' ').trim();
  if (!newName) {
    return await conn.sendMessage(m.chat, {
      text: '⚠️ Masukkan nama baru grup.\nContoh: *.setnamegc Nama Grup Baru*',
    }, { quoted: m });
  }

  await conn.groupUpdateSubject(m.chat, newName);
  await conn.sendMessage(m.chat, {
    text: `✅ Nama grup berhasil diubah menjadi: *${newName}*`,
  }, { quoted: m });
}  
    
    
 //🆂🅴🆃🆃🆃 🅳🅴🆂🅺🆁🅸🅿🆂🅸 🅶🆁🆄🅿   
  // 📝 SETDESK - Ganti deskripsi grup (khusus admin)
if (command.startsWith('.setdesk') || command.startsWith('.setdesc')) {
  if (m.isGroup === false) return;

  const groupMetadata = await conn.groupMetadata(m.chat);
  const participants = groupMetadata.participants;
  const senderId = conn.decodeJid(m.sender || m.key.participant || '');
  const isAdmin = participants.find(p => p.id === senderId)?.admin;

  if (!isAdmin) {
    return await conn.sendMessage(m.chat, {
      text: '❌ Hanya admin yang bisa mengubah deskripsi grup.',
    }, { quoted: m });
  }

  const newDesc = text?.split(' ').slice(1).join(' ').trim();
  if (!newDesc) {
    return await conn.sendMessage(m.chat, {
      text: '⚠️ Masukkan deskripsi baru.\nContoh: *.setdesk Selamat datang di grup Syuzo!*',
    }, { quoted: m });
  }

  await conn.groupUpdateDescription(m.chat, newDesc);
  await conn.sendMessage(m.chat, {
    text: `✅ Deskripsi grup berhasil diubah.`,
  }, { quoted: m });
}  
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
//💠 .🆃🅴🆂🆂🆂🆂💠 
  if (command === '.tes') {
      if (m.isGroup === false) return;
    const buttons = [
      { buttonId: '.ok', buttonText: { displayText: 'Done ✅' }, type: 1 }
    ];
    const buttonMessage = {
      text: '✅ Bot aktif kak!',
      footer: 'Syuzo V2',
      buttons,
      headerType: 1
    };
    await conn.sendMessage(m.chat, buttonMessage, { quoted: m });
  }


// 🧑‍💼 .🅾🆆🅽🅴🆁🆁🆁🆁🧑‍💼 
  if (command === '.owner') {
    const vcard = `BEGIN:VCARD
VERSION:3.0
N:Yus;;;
FN:Yuss
TEL;type=CELL;type=VOICE;waid=6283176775170:+62 831-7677-5170
END:VCARD`;
    await conn.sendMessage(m.chat, {
      contacts: {
        displayName: 'Owner Bot',
        contacts: [{ vcard }]
      }
    }, { quoted: m });
  }







// ====== 📝 FITUR .DAFTAR 📝 ==================== //
  if (command.startsWith('.daftar')) {
      if (m.isGroup === false) return;
    const input = text.split(' ')[1];
    if (!input || input.split(',').length < 2) {
      return conn.sendMessage(m.chat, {
        text: `⚠️ Maaf, kamu belum daftar.

Untuk menggunakan bot ini, Anda perlu mendaftar terlebih dahulu.

╭────〔 📋 \`CARA DAFTAR\` 〕──╮
│ ➤ Format : .daftar Nama,Umur
│ ➤ Contoh : .daftar Yus,17
╰──────────────────────╯


📌 Mengapa harus mendaftar?
• Bot kami memerlukan identitas dasar Anda.
• Pendaftaran memberi Anda akses fitur.
• Data Anda akan disimpan dengan aman.

`
      }, { quoted: m });
    }

    if (user.nama) {
      return conn.sendMessage(m.chat, {
        text: `✅ Kamu sudah terdaftar sebagai *${user.nama}*`
      }, { quoted: m });
    }

    const [nama, umur] = input.split(',');
    updateUser(sender, {
      nama: nama.trim(),
      umur: umur.trim()
    });

    await conn.sendMessage(m.chat, {
      text: `✅ Pendaftaran berhasil!

📛 Nama   : ${nama}
🎂 Umur   : ${umur}

Selamat datang di Syuzo V2! 🎉`
    }, { quoted: m });
  }
// =========================================






// .🅼🅴🅴🅴🅴🅴🅴🅴
  if (command === '.me' || command === '.profil') {
    if (m.isGroup === false) return;
  if (!user.nama) {
    return conn.sendMessage(m.chat, {
      text: `⚠️ Maaf, kamu belum terdaftar.

╭────〔 📋 \`CARA DAFTAR\` 〕──╮
│ ➤ Format : .daftar Nama,Umur
│ ➤ Contoh : .daftar Yus,17
╰──────────────────────╯

📌 Mengapa harus mendaftar?
• Bot kami memerlukan identitas dasar Anda.
• Pendaftaran memberi Anda akses ke fitur.
• Data Anda akan disimpan dengan aman.
`
    }, { quoted: m });
  }

  const xpNeeded = user.level * 100;

  const teks = `╭──〔 👤 PROFIL ANDA 〕───⭓
│ 📛 Nama     : *${user.nama}*
│ 🎂 Umur     : *${user.umur}*
│
│ 💰 Uang     : *Rp ${user.uang.toLocaleString()}*
│ ⭐ Level    : *${user.level}* (*${user.xp}/${xpNeeded}*)
│ ⚡ Stamina  : *${user.stamina}*
│ 🔖 Limit    : *${user.limit}*
│ 🎟️ tiket    : *${user.tiket}*
│ ❤️ HP       : *${user.heal}*
╰─────────────────────⭓`;

  await conn.sendMessage(m.chat, {
    text: teks,
    footer: 'Ketik .ok untuk menutup profil',
    buttons: [
      {
        buttonId: '.ld',
        buttonText: { displayText: '🤴Leaderboard' },
        type: 1
      }
    ],
    headerType: 1
  }, { quoted: m });
}

  
 //🆂🅴🅻🅵 🅿🆄🅱🅻🅸🅺🅺   
if (command === '.self') {
  const sender = conn.decodeJid(m.sender || m.key.participant || m.key.remoteJid || '').split('@')[0];
  if (sender !== constOwner) return conn.sendMessage(m.chat, { text: '❌ Kamu bukan owner.' }, { quoted: m });
  global.isPublic = false;
  conn.sendMessage(m.chat, { text: '✅ Berhasil ubah ke mode self' }, { quoted: m });
}

if (command === '.public') {
  const sender = conn.decodeJid(m.sender || m.key.participant || m.key.remoteJid || '').split('@')[0];
  if (sender !== constOwner) return conn.sendMessage(m.chat, { text: '❌ Kamu bukan owner.' }, { quoted: m });
  global.isPublic = true;
  conn.sendMessage(m.chat, { text: '✅ Berhasil ubah ke mode public' }, { quoted: m });
}
//🅿🆁🅴🅼🅸🆄🅼🅼🅼🅼🅼🅼🅼
  // 👑 MENU OWNER: PREMIUM 👑 

if (command.startsWith('.addprem')) {
  const senderJid = m.sender || m.key.participant || m.key.remoteJid || '';
  const sender = conn.decodeJid(senderJid).split('@')[0];

  if (sender !== constOwner) {
    return await conn.sendMessage(m.chat, { text: '❌ Khusus owner!' }, { quoted: m });
  }

  const input = text.replace(/[^0-9]/g, ''); // ambil angka dari input
  const number = m.mentionedJid?.[0]?.split('@')[0] || input;

  if (!number) {
    return await conn.sendMessage(m.chat, { text: '⚠️ Masukkan nomor atau tag user!' }, { quoted: m });
  }

  if (premium.includes(number)) {
    return await conn.sendMessage(m.chat, {
      text: `⚠️ @${number} sudah premium.`,
      mentions: [`${number}@s.whatsapp.net`]
    }, { quoted: m });
  }

  premium.push(number);
  fs.writeFileSync(premPath, JSON.stringify(premium, null, 2));

  return await conn.sendMessage(m.chat, {
    text: `✅ @${number} telah ditambahkan ke premium.`,
    mentions: [`${number}@s.whatsapp.net`]
  }, { quoted: m });
}

  

  if (command.startsWith('.delprem')) {
  const senderJid = m.sender || m.key.participant || m.key.remoteJid || '';
  const sender = conn.decodeJid(senderJid).split('@')[0];

  if (sender !== constOwner) {
    return await conn.sendMessage(m.chat, { text: '❌ Khusus owner!' }, { quoted: m });
  }

  const input = text.replace(/[^0-9]/g, '');
  const number = m.mentionedJid?.[0]?.split('@')[0] || input;

  if (!number) {
    return await conn.sendMessage(m.chat, { text: '⚠️ Masukkan nomor atau tag user!' }, { quoted: m });
  }

  if (!premium.includes(number)) {
    return await conn.sendMessage(m.chat, {
      text: `⚠️ @${number} belum jadi user premium.`,
      mentions: [`${number}@s.whatsapp.net`]
    }, { quoted: m });
  }

  premium = premium.filter(n => n !== number);
  fs.writeFileSync(premPath, JSON.stringify(premium, null, 2));

  return await conn.sendMessage(m.chat, {
    text: `🗑️ @${number} telah dihapus dari user premium.`,
    mentions: [`${number}@s.whatsapp.net`]
  }, { quoted: m });
}
  
  

  


  

if (command === '.listprem') {
  const senderJid = m.sender || m.key.participant || m.key.remoteJid || '';
  const sender = conn.decodeJid(senderJid).split('@')[0];

  if (sender !== constOwner) {
    return conn.sendMessage(m.chat, {
      text: '❌ Khusus owner!'
    }, { quoted: m });
  }

  if (premium.length === 0) {
    return conn.sendMessage(m.chat, {
      text: '📭 Belum ada user premium.'
    }, { quoted: m });
  }

  const list = premium.map((num, i) => `${i + 1}. wa.me/${num}`).join('\n');
  conn.sendMessage(m.chat, {
    text: `👑 List User Premium:\n\n${list}`
  }, { quoted: m });
}

    
    
// 🧠 XP & Level Up Sistem
if ((m.isGroup || !m.isGroup) && typeof text === 'string' && text.startsWith('.')) {
  const userData = users[sender];

  // Hanya jika user sudah terdaftar
  if (!userData || !userData.nama) return;

  const oldLevel = userData.level;
  const oldXp = userData.xp;

  // Tambah XP
  userData.xp += 5;

  // XP yang dibutuhkan untuk naik level sekarang
  const xpNeeded = userData.level * 100;

  if (userData.xp >= xpNeeded) {
    userData.level += 1;
    userData.xp = 0;

    const nextXp = userData.level * 80;

    // Kirim pesan Level Up dengan gambar dan ASCII
    const caption = `🎉 *LEVEL UP!*
╭───⊷
│ 👤 Nama      : *${userData.nama}*
│ 🆙 Level     : *${oldLevel} ➜ ${userData.level}*
│ 📈 XP       : *0/${nextXp} XP*
╰────────────⊷`;


    await conn.sendMessage(m.chat, {
      image: { url: './image/levelup/level.jpg' },
      caption,
      mentions: [senderJid]
    }, { quoted: m });
  }

  updateUser(sender, userData);
}    
    
    
    
//🅴🅽🅳🅳🅳🅳🅳
};





    

 
    


    




    
    
    
    
    

       
    
    
    
    
    
    
    
    
    
