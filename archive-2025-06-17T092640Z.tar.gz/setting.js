global.owner = ["6283176775170"];
global.bot = "6283159416085";
global.namabot = "Syuzo V2";
global.namaown = "Yus";

module.exports = global;